# Handoff: TangoHost About / Product Page

## Overview
A public marketing page for the TangoHost website that introduces the product: what it's for, the values behind it, and its privacy model. Single scrolling page, no interactive state. Intended to sit on the main site as the "about" or product-overview page.

## About the Design Files
The file in this bundle (`TangoHost About Page.dc.html` + `support.js`) is a **design reference built as an HTML prototype** — it shows intended look, layout, and copy, not production code to copy verbatim. Recreate this page in the site's existing environment (its framework, component library, routing, and CMS if copy is managed there), matching the visuals and copy below. `support.js` is the prototyping tool's runtime and has no equivalent in a real codebase — ignore it.

## Fidelity
**High-fidelity.** Colors, type sizes/weights, spacing, and all copy are final as shown.

## Page Structure
Five stacked full-width bands. Content inside each band is constrained to `max-width: 1040px`, centered, with 40px side padding. Bands alternate background color to separate sections (cream → white → cream → dark → cream).

### Band 1 — Hero (cream background, centered text)
Padding 110px top / 90px bottom.
- Eyebrow: "TangoHost" — 15px, weight 700, uppercase, letter-spacing 0.14em, accent color.
- Headline: "Travel further, together." — Fraunces serif, 60px, weight 700, letter-spacing -0.015em, line-height 1.08.
- Subhead: "TangoHost connects dancers whose journeys overlap, so the practical parts of a trip — the ride, the room — get easier to sort out." — 20px, `oklch(42% 0.02 75)`, max-width 620px centered, line-height 1.6.

### Band 2 — "Why we built it" (white background)
Padding 90px vertical. Section heading in Fraunces 34px weight 700, then a 3-column grid (32px gap) of value props. Each column: a 44×44 rounded-square icon tile (radius 14px, background `oklch(94% 0.04 40)`, accent-colored 22px icon inside), then a Fraunces 21px weight 700 title, then 16.5px body copy in `oklch(42% 0.02 75)`.

1. **Travel more, spend less** (car icon) — "A shared taxi and a shared room turn a trip you were weighing into a trip you take."
2. **Arrive knowing someone** (people icon) — "Reconnect with old friends, meet new ones — the ride from the airport is where it starts."
3. **Travel changes you** (globe icon) — "New cities, new floors, new people. Going further widens what you think is possible."

### Band 3 — "What you can do" (cream background)
Padding 90px vertical. Section heading (Fraunces 34px weight 700), then a 2-column card grid (16px gap, 6 cards → 3 rows). Each card: white background, radius 20px, padding 26px 28px, shadow `0 1px 2px rgba(0,0,0,0.04), 0 1px 8px rgba(0,0,0,0.03)`; Fraunces 20px weight 700 title, 16px body in `oklch(42% 0.02 75)`.

1. **Share a ride** — "Post your airport arrival, see who lands near your time, split the taxi."
2. **Share a room** — "Offer a spare bed or find one — hotel or Airbnb, for the nights you need."
3. **Host, or find a host** — "Open your home to a visiting dancer, or stay with a local when you travel."
4. **Offer seats in your car** — "Driving or renting a car? Post your empty seats and pick up dancers along the way."
5. **Organizer shuttles** — "Running a shuttle for your event? Post it so guests can find and book a seat."
6. **Find a registration partner** — "For events that require couples registration, find someone to sign up with."

### Band 4 — "Controlled visibility" (dark background `oklch(24% 0.03 40)`)
Padding 90px vertical. This band is the privacy/values statement and is deliberately the only dark section — it's the visual anchor of the page.
- Eyebrow: "Controlled visibility" — 14px, weight 700, uppercase, letter-spacing 0.14em, color `oklch(75% 0.11 40)` (light accent tint).
- Heading: "Only see what you need to see." — Fraunces 34px weight 700, `oklch(97% 0.01 75)`, max-width 700px.
- Subhead: "Coordinating travel shouldn't mean broadcasting your plans to a whole group chat." — 18px, `oklch(78% 0.02 75)`, max-width 640px.
- 2-column grid (16px gap, 4 cards) of outlined cards: border `1px solid oklch(38% 0.03 40)`, radius 18px, padding 24px 26px, transparent fill. Title Fraunces 19px weight 700 in `oklch(97% 0.01 75)`, body 15.5px in `oklch(76% 0.02 75)`.
  1. **You're visible to the right people** — "Only the people looking for the same thing, at the same time, see that you're looking too."
  2. **Hosts stay in control** — "You decide who sees your details, and when. Your address isn't a public listing."
  3. **Tap to answer** — "Accept or decline in one tap. Less typing, fewer threads to keep up with."
  4. **Say no without explaining** — "Declining is a button, not a conversation. No reason required, no awkwardness."

### Band 5 — Closing CTA (cream background, centered)
Padding 100px top / 130px bottom.
- Heading: "Going somewhere soon?" — Fraunces 40px weight 700.
- Subhead: "Add your trip and see who else is on their way." — 18px, `oklch(42% 0.02 75)`, max-width 520px centered.
- Button: "Get started" — pill (radius 999px), accent background, white text 16.5px weight 700, padding 15px 38px. **Wire this to your signup/app entry route** — it's a static element in the prototype.

## Interactions & Behavior
Static content page — no state, forms, or interactive components. The only actionable element is the "Get started" CTA button. Add hover/focus states per the site's existing button conventions.

## Responsive notes
The prototype is authored at desktop width. For narrower viewports: collapse the 3-column "Why we built it" grid and both 2-column card grids to a single column, and step the display type down (hero 60px → ~38px, section headings 34px → ~26px). Band padding can reduce from 90px to ~56px vertical.

## Design Tokens

**Colors**
- Page background (cream): `oklch(97% 0.015 65)`
- Alternate band background: `#fff`
- Dark band background: `oklch(24% 0.03 40)`
- Accent: `#ED6558` (coral) — used for the eyebrow, icon glyphs, and the CTA button. Read this from the app's `accentColor` theme token rather than hardcoding; see `Coral Pink Color Scheme.md`.
- Accent tint (icon tile background): `oklch(94% 0.04 40)`
- Light accent (on dark band): `oklch(75% 0.11 40)`
- Primary text: `oklch(20% 0.02 75)`; on dark band: `oklch(97% 0.01 75)`
- Secondary text: `oklch(42% 0.02 75)`; on dark band: `oklch(76–78% 0.02 75)`
- Dark-band card border: `oklch(38% 0.03 40)`

**Typography**
- Display/headings: Fraunces (serif), weights 600–700
- Body/UI: Work Sans (sans-serif), weights 400–700
- Scale: hero 60px · section heading 34px · CTA heading 40px · card title 19–21px · body 15.5–20px

**Spacing / radii**
- Content max-width 1040px, 40px side padding
- Band vertical padding: 90px (hero 110/90, CTA 100/130)
- Card radius 20px (dark band 18px), icon tile radius 14px, button radius 999px

**Links**
`a { color: #ED6558 }`, hover `oklch(52% 0.16 30)`. Defined even though the page currently has no inline links — keep them defined so any copy edits don't fall back to browser-default blue.

## Assets
No photographic assets. All icons are inline SVG (car, people, globe) — see markup for exact paths. If the site has an existing icon set, substitute equivalents at 22px.

## Files
- `TangoHost About Page.dc.html` — the full page.
- `support.js` — prototyping runtime (reference only, not to be ported).
